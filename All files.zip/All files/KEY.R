library(stringr)
library(ggplot2)
library(xtable)

## Simulation Data
k_PCS	= c(49.5, 53.4,	27.4, 35.4,	30.6, 59.5,	51.2, 52.6,	48.7, 53.9,	26.1, 32.6,	37.4, 0, 0)
k_PAS = c(85.7, 72.3, 73.4, 72.8, 46.5, 59.6, 66.4, 82.1, 48.7, 53.9, 26.1, 57.9, 37.4, 0, 0)
k_ntox = c(6.9, 8.2,  7.9,	8.7,	9.5,  9.5,	9.8,	8.9,	9.9, 10.4, 8.9, 10.2, 9.1, 5.9, 3.5)
k_npat = c(35.7, 35.7, 36.0, 35.7, 36.0, 34.8,	34.6, 35.7,	34.8, 33.3,	36.0, 31.1,	24.7, 12.5,	34.9)
k_PCE = c(29.9, 32.6,	16.6, 20.1,	20.3, 42.3,	33.1, 30.8,	36.6, 44.8,	22.2, 25.8,	56.6, 0, 0)
k_PEOVER =  c(0, 12.6, 17.2, 19.3, 28.9, 19.5, 23.7, 17.7, 30.2, 30.3, 30.8, 37.9, 43.3, 100, 0)
k_OVER = c(0, 12.7, 15.2, 13.1, 24.4, 19.6, 19.9, 13.9, 29.5, 25.9, 22.3, 26.3, 22.1, 14.7, 0)
k_PAE = c(56.9, 41.7, 45.0, 47.1, 37.2, 42.3, 49.1, 55.7, 36.6, 44.8, 22.2, 61.7, 56.6, 0, 0)
k_ZERO = c(0.8, 0.9, 0, 0.9, 0.1, 3.5, 4.4, 0.7, 3.7, 8.4, 0, 15.8, 40.5, 85.3, 3.3 )
save(k_PCS,k_PAS,k_PCE,k_PAE,k_OVER,k_PEOVER,k_npat,k_ntox,k_ZERO,file="key_sim.RData")

xtable(n1,digits=1)
xtable(n2,digits=1)
xtable(n3,digits=1)
xtable(n4,digits=1)
xtable(n5,digits=1)
xtable(n6,digits=1)
xtable(n7,digits=1)
xtable(n8,digits=1)
xtable(n9,digits=1)
xtable(n10,digits=1)
xtable(n11,digits=1)
xtable(n12,digits=1)
xtable(n13,digits=1)
xtable(n14,digits=1)
xtable(n15,digits=1)

xtable(d1,digits=1)
xtable(d2,digits=1)
xtable(d3,digits=1)
xtable(d4,digits=1)
xtable(d5,digits=1)
xtable(d6,digits=1)
xtable(d7,digits=1)
xtable(d8,digits=1)
xtable(d9,digits=1)
xtable(d10,digits=1)
xtable(d11,digits=1)
xtable(d12,digits=1)
xtable(d13,digits=1)
xtable(d14,digits=1)
xtable(d15,digits=1)

n1=matrix(nrow=3,ncol=3,byrow=T,c(
  3.6,	2.5,	2.1,
  2.3,	3.2,	4.8,
  2,	4.4,	10.7))

n2=matrix(nrow=3,ncol=3,byrow=T,c(			
  3.7,	2.5,	2.9,
  2.7,	4.4,	5.9,
  3.2,	5.8,	4.5))

n3=matrix(nrow=3,ncol=3,byrow=T,c(			
  3.3,	1.9,	2.2,
  2.6,	3.6,	7.3,
  2.9,	6,	6.2))

n4=matrix(nrow=3,ncol=3,byrow=T,c(			
  3.6,	2.4,	3,
  2.8,	5.2,	7.2,
  4.6,	4.6,	2.3))

n5=matrix(nrow=3,ncol=3,byrow=T,c(
  3.7,	2.7,	5.8,
  6.1,	7.3,	4.7,
  3,	2,	0.7))

n6=matrix(nrow=3,ncol=3,byrow=T,c(
  4.5,	4.5,	4.5,
  4.2,	6.2,	3.1,
  4.1,	2.9,	0.8))

n7=matrix(nrow=3,ncol=3,byrow=T,c(		
  4.9,	5.5,	2.7,
  4.5,	7.1,	2.2,
  4.4,	2.8,	0.5))

n8=matrix(nrow=3,ncol=3,byrow=T,c(		
  3.6,	2.7,	3.4,
  3.3,	5.5,	6.9,
  4.1,	4.1,	2.2))

n9=matrix(nrow=3,ncol=3,byrow=T,c(		
  5.7,	5.8,	6.3,
  6.4,	4.8,	1.8,
  2.4,	1.2,	0.3))

n10=matrix(nrow=3,ncol=3,byrow=T,c(	
  8.3,	7.5,	2.6,
  7.4,	3.5,	0.7,
  2.6,	0.6,	0.1))

n11=matrix(nrow=3,ncol=3,byrow=T,c(
  4.6,	3.5,	8.8,
  8,	5.5,	2.1,
  2.6,	0.8,	0.1))

n12=matrix(nrow=3,ncol=3,byrow=T,c(
  11.2,	8,	2.9,
  5.6,	2.1,	0.4,
  0.7,	0.1,	0))

n13=matrix(nrow=3,ncol=3,byrow=T,c(
  14,	4.1,	0.7,
  4.2,	0.8,	0.1,
  0.7,	0.1,	0))

n14=matrix(nrow=3,ncol=3,byrow=T,c(			
  9.5,	1.2,	0.2,
  1.4,	0.2,	0,
  0.2,	0,	0))

n15=matrix(nrow=3,ncol=3,byrow=T,c(			
  4.2,	2.1,	1.1,
  2.2,	2.2,	2.1,
  1.4,	2.2,	17.3))

##################

d1=matrix(nrow=3,ncol=3,byrow=T,c(			
  0,	0.4, 5.1,
  0.3,	2.3,	19.4,
  5.4,	16.8,	49.5))

d2=matrix(nrow=3,ncol=3,byrow=T,c(		
  0.1,	0.9,	10.5,
  0.8,	9.5,	27.5,
  11.2,	25.9,	12.7))

d3=matrix(nrow=3,ncol=3,byrow=T,c(			
  0,	0.1,	5.8,
  0.5,	5,	37,
  9,	27.4,	15.2))

d4=matrix(nrow=3,ncol=3,byrow=T,c(		
  0,	0.6,	11.3,
  1.3,	16.1,	35.4,
  21.3,	11.8,	1.3))

d5=matrix(nrow=3,ncol=3,byrow=T,c(		
  0.1,	1.9,	27,
  15.9,	30.6,	13.8,
  7.5,	2.9,	0.2))

d6=matrix(nrow=3,ncol=3,byrow=T,c(			
  0.6,	8.3,	18.8,
  8.2,	24,	9.9,
  16.8,	9.3,	0.6))

d7=matrix(nrow=3,ncol=3,byrow=T,c(		
  1,	15.2,	7.7,
  8.3,	31.4,	5.5,
  19.8,	6.3,	0.4))

d8=matrix(nrow=3,ncol=3,byrow=T,c(		
  0,	1.2,	12.6,
  2.1,	16.8,	35.9,
  16.8,	11.8,	2.1))

d9=matrix(nrow=3,ncol=3,byrow=T,c(		
  2.4,	15.7,	29.9,
  18.8,	15,	2.9,
  8.5,	2.8,	0.3))

d10=matrix(nrow=3,ncol=3,byrow=T,c(			
  11.8,	27.5,	7.8,
  26.4,	8.8,	1.2,
  7.3,	0.8,	0))

d11=matrix(nrow=3,ncol=3,byrow=T,c(		
  1.1,	3.6,	46.9,
  26.1,	13.5,	1,
  7.4,	0.4,	0))

d12=matrix(nrow=3,ncol=3,byrow=T,c(		
  25.3,	32.6,	10.1,
  11.5,	3.8,	0.2,
  0.5,	0.2,	0))

d13=matrix(nrow=3,ncol=3,byrow=T,c(		
  37.4,	8.9,	1.5,
  9.2,	1.1,	0,
  1.2,	0.2,	0))

d14=matrix(nrow=3,ncol=3,byrow=T,c(	
  11.8,	1.1,	0.2,
  1.3,	0.2,	0,
  0.1,	0,	0))

d15=matrix(nrow=3,ncol=3,byrow=T,c(			
  0,	0.2,	1,
  0.2,	0.5,	2.1,
  1.7,	2.2,	88.8))

####################################################################################

## Note all simulations run on trialdesign.org