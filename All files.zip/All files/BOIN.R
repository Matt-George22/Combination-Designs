library(BOIN)

#############################################################################   

## calibrating interval
set.seed(100)

true1=matrix(nrow=3,ncol=3,c(0.05,0.1,0.15,0.1,0.15,0.2,0.15,0.2,0.3))
true2=matrix(nrow=3,ncol=3,c(0.05,0.1,0.3,0.1,0.2,0.45,0.2,0.3,0.55))
true3=matrix(nrow=3,ncol=3,c(0.15,0.3,0.45,0.3,0.45,0.55,0.45,0.55,0.65))
true4=matrix(nrow=3,ncol=3,c(0.3,0.45,0.5,0.45,0.5,0.55,0.5,0.55,0.6))

a=seq(from=0.85,to=0.40,by=-0.05)
b=seq(from=1.15,to=1.60,by=0.05)

sc1=matrix(NA,nrow=length(a),ncol=length(b))
for(x1 in 1:length(a)){
  for(x2 in 1:length(b)){
    simulation=get.oc.comb(target=0.3, p.true=true1, ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                           p.saf = 0.3*a[x1], p.tox = 0.3*b[x2], cutoff.eli = 1, extrasafe = FALSE, offset = 0.05,
                           ntrial = 4000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
    sc1[x1,x2]=simulation$pcs
  }
}
sc1

sc2=matrix(NA,nrow=length(a),ncol=length(b))
for(x1 in 1:length(a)){
  for(x2 in 1:length(b)){
    simulation=get.oc.comb(target=0.3, p.true=true2, ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                           p.saf = 0.3*a[x1], p.tox = 0.3*b[x2], cutoff.eli = 1, extrasafe = FALSE, offset = 0.05,
                           ntrial = 4000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
    sc2[x1,x2]=simulation$pcs
  }
}
sc2

sc3=matrix(NA,nrow=length(a),ncol=length(b))
for(x1 in 1:length(a)){
  for(x2 in 1:length(b)){
    simulation=get.oc.comb(target=0.3, p.true=true3, ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                           p.saf = 0.3*a[x1], p.tox = 0.3*b[x2], cutoff.eli = 1, extrasafe = FALSE, offset = 0.05,
                           ntrial = 4000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
    sc3[x1,x2]=simulation$pcs
  }
}
sc3

sc4=matrix(NA,nrow=length(a),ncol=length(b))
for(x1 in 1:length(a)){
  for(x2 in 1:length(b)){
    simulation=get.oc.comb(target=0.3, p.true=true4, ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                           p.saf = 0.3*a[x1], p.tox = 0.3*b[x2], cutoff.eli = 1, extrasafe = FALSE, offset = 0.05,
                           ntrial = 4000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
    sc4[x1,x2]=simulation$pcs
  }
}
sc4

sc1=matrix(as.numeric(sub("%", "", sc1)),nrow=length(a),ncol=length(b))
sc2=matrix(as.numeric(sub("%", "", sc2)),nrow=length(a),ncol=length(b))
sc3=matrix(as.numeric(sub("%", "", sc3)),nrow=length(a),ncol=length(b))
sc4=matrix(as.numeric(sub("%", "", sc4)),nrow=length(a),ncol=length(b))

sc1
sc2
sc3
sc4

###############################################################################################

## Averaging PCS across scenarios

#geometric mean and maximin
gm=mm=matrix(NA,nrow=length(a),ncol=length(b))
for(i in 1:length(a)){
  for(j in 1:length(b)){
    gm[i,j]=(sc1[i,j]*sc2[i,j]*sc3[i,j]*sc4[i,j])^(0.25)
    mm[i,j]=min(c(sc1[i,j],sc2[i,j],sc3[i,j],sc4[i,j]))
  }
}
round(gm,1)
round(mm,1)
max(gm)
min(gm)
which(gm==max(gm),arr.ind=TRUE)

x = seq(0.85,0.40,by=-0.05)
y = seq(1.15,1.60,by=0.05)
data <- expand.grid(X=x, Y=y)
data$GM <- as.vector(gm)

library(ggplot2)
pdf(file="fig_BOIN_int.pdf",width=4,height=3)
ggplot(data,aes(x=X,y=Y,fill=GM)) + geom_tile() + scale_fill_gradient(low="white", high="darkblue",limits=c(53,63)) + 
  labs(x=expression(a[1]),y=expression(a[2]),fill="Mean \nPCS (%)") + theme(legend.key.height=unit(1, "cm")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

ggplot(data,aes(x=data$X,y=data$Y,fill=(data$MM))) + geom_tile() + scale_fill_gradient(low="white", high="black")

#################################################################################################

## calibrate safety constraint
set.seed(400)

trueTOX=matrix(nrow=3,ncol=3,c(0.45,0.5,0.55,0.5,0.55,0.6,0.55,0.6,0.65))
trueSAFE=matrix(nrow=3,ncol=3,c(0.3,0.45,0.5,0.45,0.5,0.55,0.5,0.55,0.6))
epsilon=seq(from=1,to=0.7,by=-0.02)
a=0.65
b=1.4

tox_sc1=vector()
for(y1 in 1:length(epsilon)){
  simulation = get.oc.comb(target=0.3, p.true=trueTOX, ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                           p.saf = 0.3*a, p.tox = 0.3*b, cutoff.eli = epsilon[y1], extrasafe = FALSE, offset = 0.05,
                           ntrial = 4000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
  pstop = 100-sum(simulation$selpercent)
  tox_sc1[y1] = pstop
}
tox_sc1

tox_sc2=vector()
tox_sc2a=vector()
for(y1 in 1:length(epsilon)){
  simulation = get.oc.comb(target=0.3, p.true=trueSAFE, ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                           p.saf = 0.3*a, p.tox = 0.3*b, cutoff.eli = epsilon[y1], extrasafe = FALSE, offset = 0.05,
                           ntrial = 4000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
  pnostop = sum(simulation$selpercent)
  pcs = simulation$pcs
  tox_sc2[y1] = pnostop
  tox_sc2a[y1] = as.numeric(sub("%", "", pcs))
}
tox_sc2a 

library(ggplot2)
pdf(file="fig_BOIN_safe.pdf",width=4.6,height=3.4)
ggplot() + geom_line(aes(x=epsilon,y=tox_sc1,col="red"),size=0.8) + geom_line(aes(x=epsilon,y=tox_sc2a,col="green"),size=0.8) + ylim(0,100) +
  labs(x=expression(epsilon),y="Correct Outcome (%)",color=NULL) +  scale_color_manual(values=c("green"="green","red"="red"), labels=c("Sc 13","Sc 14")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

which(tox_sc1>85)
epsilon[9]

#####################################################################################################

## Interpret Interval
phi=0.3
phi1=0.65*phi
phi2=1.4*phi

l_e=log((1-phi1)/(1-phi))/log((phi*(1-phi1))/(phi1*(1-phi)))
l_d=log((1-phi)/(1-phi2))/log((phi2*(1-phi))/(phi*(1-phi2)))
round(c(l_e,l_d),3)

#####################################################################################################

## Simulation

set.seed(1)
s1=matrix(c(0.05,0.10,0.15,0.10,0.15,0.20,0.15,0.20,0.30),nrow=3,ncol=3)
s2=matrix(c(0.05,0.10,0.20,0.10,0.20,0.30,0.15,0.30,0.45),nrow=3,ncol=3)
s3=matrix(c(0.02,0.10,0.20,0.05,0.15,0.30,0.10,0.20,0.45),nrow=3,ncol=3)
s4=matrix(c(0.05,0.10,0.20,0.10,0.20,0.45,0.15,0.30,0.60),nrow=3,ncol=3)
s5=matrix(c(0.02,0.20,0.45,0.05,0.30,0.55,0.15,0.45,0.65),nrow=3,ncol=3)
s6=matrix(c(0.10,0.15,0.30,0.15,0.30,0.45,0.30,0.45,0.60),nrow=3,ncol=3)
s7=matrix(c(0.10,0.15,0.30,0.20,0.30,0.50,0.45,0.50,0.60),nrow=3,ncol=3)
s8=matrix(c(0.05,0.10,0.30,0.10,0.20,0.45,0.20,0.30,0.55),nrow=3,ncol=3)
s9=matrix(c(0.10,0.30,0.40,0.15,0.40,0.50,0.30,0.50,0.60),nrow=3,ncol=3)
s10=matrix(c(0.15,0.30,0.45,0.30,0.45,0.55,0.45,0.55,0.65),nrow=3,ncol=3)
s11=matrix(c(0.02,0.30,0.45,0.05,0.45,0.60,0.10,0.60,0.75),nrow=3,ncol=3)
s12=matrix(c(0.20,0.45,0.65,0.30,0.50,0.70,0.45,0.55,0.75),nrow=3,ncol=3)
s13=matrix(c(0.30,0.45,0.50,0.45,0.50,0.55,0.50,0.55,0.60),nrow=3,ncol=3)
s14=matrix(c(0.45,0.50,0.55,0.50,0.55,0.60,0.55,0.60,0.65),nrow=3,ncol=3)
s15=matrix(c(0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10),nrow=3,ncol=3)
scenario=list(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15)

PCS=PAS=PCE=PAE=OVER=PEOVER=ntox=npat=rep(NA,15)
EXTRA=SEL=EXP=list()
for(x1 in 1:15){
  trial=get.oc.comb(target=0.3, p.true=scenario[[x1]], ncohort=12, cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                    p.saf = 0.3*0.65, p.tox = 0.3*1.4, cutoff.eli = 0.84, extrasafe = FALSE, offset = 0.05,
                    ntrial = 2000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
  mtd=which(scenario[[x1]]==0.30,arr.ind=T)
  mtds=which((scenario[[x1]]>0.16 & scenario[[x1]]<0.33),arr.ind=T)
  over=which(scenario[[x1]]>0.33,arr.ind=T)
  
  #PCS, PAS, PCE
  if(dim(mtd)[1]!=0){
    pcs=vector()
    pas=vector()
    pce=vector()
    pae=vector()
    for(z in 1:dim(mtd)[1]){
      pcs[z]=trial$selpercent[mtd[z,1],mtd[z,2]]
      pce[z]=100 * trial$npatients[mtd[z,1],mtd[z,2]]/trial$totaln
    }
    for(z in 1:dim(mtds)[1]){
      pas[z]=trial$selpercent[mtds[z,1],mtds[z,2]]
      pae[z]=100 * trial$npatients[mtds[z,1],mtds[z,2]]/trial$totaln
    }
    PCS[x1]=sum(pcs)
    PAS[x1]=sum(pas)
    PCE[x1]=sum(pce)
    PAE[x1]=sum(pae)
    EXTRA[[x1]]=pcs
  }else{
    PCS[x1]=0
    PAS[x1]=0
    PCE[x1]=0
    PAE[x1]=0
  }
  
  #Overtoxic rec
  if(dim(over)[1]!=0){
    otox=vector()
    peover=vector()
    for(z in 1:dim(over)[1]){
      otox[z]=trial$selpercent[over[z,1],over[z,2]]
      peover[z]=100*trial$npatients[over[z,1],over[z,2]]/trial$totaln
    }
    OVER[x1]=sum(otox)
    PEOVER[x1]=sum(peover)
  }else{
    OVER[x1]=0
    PEOVER[x1]=0
  }
  
  #Number of patients and DLTs
  ntox[x1]=trial$totaltox
  npat[x1]=trial$totaln
  
  #sel and exp
  SEL[[x1]]=trial$selpercent
  EXP[[x1]]=trial$npatients
}

b_PCS=PCS
b_PAS=PAS
b_OVER=OVER
b_PEOVER=PEOVER
b_PEOVER[14]=100
b_PCE=PCE
b_PAE=PAE
b_ntox=ntox
b_npat=npat
b_EXTRA=EXTRA
b_SEL=SEL
b_EXP=EXP

#########################################################################################################

## Sensitivity Analysis
set.seed(10)
s1=matrix(c(0.05,0.10,0.15,0.10,0.15,0.20,0.15,0.20,0.30),nrow=3,ncol=3)
s2=matrix(c(0.05,0.10,0.20,0.10,0.20,0.30,0.15,0.30,0.45),nrow=3,ncol=3)
s3=matrix(c(0.02,0.10,0.20,0.05,0.15,0.30,0.10,0.20,0.45),nrow=3,ncol=3)
s4=matrix(c(0.05,0.10,0.20,0.10,0.20,0.45,0.15,0.30,0.60),nrow=3,ncol=3)
s5=matrix(c(0.02,0.20,0.45,0.05,0.30,0.55,0.15,0.45,0.65),nrow=3,ncol=3)
s6=matrix(c(0.10,0.15,0.30,0.15,0.30,0.45,0.30,0.45,0.60),nrow=3,ncol=3)
s7=matrix(c(0.10,0.15,0.30,0.20,0.30,0.50,0.45,0.50,0.60),nrow=3,ncol=3)
s8=matrix(c(0.05,0.10,0.30,0.10,0.20,0.45,0.20,0.30,0.55),nrow=3,ncol=3)
s9=matrix(c(0.10,0.30,0.40,0.15,0.40,0.50,0.30,0.50,0.60),nrow=3,ncol=3)
s10=matrix(c(0.15,0.30,0.45,0.30,0.45,0.55,0.45,0.55,0.65),nrow=3,ncol=3)
s11=matrix(c(0.02,0.30,0.45,0.05,0.45,0.60,0.10,0.60,0.75),nrow=3,ncol=3)
s12=matrix(c(0.20,0.45,0.65,0.30,0.50,0.70,0.45,0.55,0.75),nrow=3,ncol=3)
s13=matrix(c(0.30,0.45,0.50,0.45,0.50,0.55,0.50,0.55,0.60),nrow=3,ncol=3)
s14=matrix(c(0.45,0.50,0.55,0.50,0.55,0.60,0.55,0.60,0.65),nrow=3,ncol=3)
s15=matrix(c(0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10),nrow=3,ncol=3)
scenario=list(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15)

prob=matrix(NA,nrow=13,ncol=5)
ncoh=c(8,10,12,14,16)

for(y1 in 1:5){
  for(x1 in 1:13){
    trial=get.oc.comb(target=0.3, p.true=scenario[[x1]], ncohort=ncoh[y1], cohortsize=3, n.earlystop = NULL, startdose = c(1,1), titration = FALSE,
                      p.saf = 0.3*0.65, p.tox = 0.3*1.4, cutoff.eli = 0.84, extrasafe = FALSE, offset = 0.05,
                      ntrial = 2000, mtd.contour = FALSE, seed = sample(1:1000000,1,replace=F))
    mtd=which(scenario[[x1]]==0.30,arr.ind=T)
    if(dim(mtd)[1]!=0){
      pcs=vector()
      for(z in 1:dim(mtd)[1]){
        pcs[z]=trial$selpercent[mtd[z,1],mtd[z,2]]
      }
      prob[x1,y1]=sum(pcs)
    }else{
      prob[x1,y1]=0
    }
  }
}
prob
means=colMeans(prob)
best=prob[3,]
worst=prob[6,]

#sam=factor(c(24,30,36,42,48))
#ss=factor(sam,levels=c("24","30","36","42","48"))
mydata1=data.frame(
  ss=c(24,30,36,42,48),
  means=means,
  best=best,
  worst=worst
)