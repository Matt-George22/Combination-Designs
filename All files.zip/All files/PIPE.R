library(pipe.design)

#################################################################################################################################

# get all the function names of the given package "mypack"
rstar <- unclass(lsf.str(envir = asNamespace("pipe.design"), all = T))

# create functions in the Global Env. with the same name
for(name in rstar) eval(parse(text=paste0(name, '<-pipe.design:::', name)))

##############################################################

## Functions

ppp=function(a,b,n,r){
  post_a=a+r
  post_b=b+n-r
  mean=post_a/(post_a+post_b)
  return(mean)
}

pickone=function(design){
  
  a=design$a
  b=design$b
  n=design$n.sim
  r=design$r.sim
  
  single=matrix(NA,nrow=2000,ncol=2)
  for(k in 1:2000){
    
    if(dim(design$rpII.list[[k]])[2]==0){
      single[k,] = c(0,0)
    }else if(dim(design$rpII.list[[k]])[2]==1){
      single[k,] = c(design$rpII.list[[k]])
    }else{
      mean=matrix(1,nrow=3,ncol=3)
      for(i in 1:3){
        for(j in 1:3){
          mean[i,j]=ppp(a[i,j],b[i,j],n[[k]][i,j],r[[k]][i,j])
        }
      }
      value = vector()
      for(v in 1:dim(design$rpII.list[[k]])[2]){
        dose = as.vector(design$rpII.list[[k]][,v])
        value[v] = abs(0.3-mean[dose[1],dose[2]])
      }
      doses=which(value==min(value))
      rand=length(doses)
      if(rand==1){
        single[k,]=as.vector(design$rpII.list[[k]][,doses])
      }else{
        choose_one=sample(doses,1)
        single[k,]=as.vector(design$rpII.list[[k]][,choose_one])
      }
    }
  }
  return(single)
}

##################################################

## Calibrating prior

set.seed(200)

low=c(0.025,0.05,0.075,0.10)
inc=c(0.025,0.05,0.075,0.10)
prior.m=function(low,inc){
  t1=low
  t2=low+inc
  t3=low+2*inc
  t4=low+3*inc
  t5=low+4*inc
  prior.med=matrix(nrow=3,ncol=3,c(t1,t2,t3,t2,t3,t4,t3,t4,t5))
  return(prior.med)
}
ss=c(1/72,1/36,1/18,1/9)

true1=matrix(nrow=3,ncol=3,c(0.05,0.1,0.15,0.1,0.15,0.2,0.15,0.2,0.3))
true2=matrix(nrow=3,ncol=3,c(0.05,0.1,0.3,0.1,0.2,0.45,0.2,0.3,0.55))
true3=matrix(nrow=3,ncol=3,c(0.15,0.3,0.45,0.3,0.45,0.55,0.45,0.55,0.65))
true4=matrix(nrow=3,ncol=3,c(0.3,0.45,0.5,0.45,0.5,0.55,0.5,0.55,0.6))


sc1=array(NA,dim=c(length(low),length(inc),length(ss)))
for(x1 in 1:length(low)){
  for(x2 in 1:length(inc)){
    for(x3 in 1:length(ss)){
      design = pipe.design(N=36,S=2000,c=3,theta=0.30,pi=true1, 
                           prior.med=prior.m(low[x1],inc[x2]), prior.ss=matrix(nrow=3,ncol=3,ss[x3]),
                           strategy="ss-random",admis="closest",constraint="neighbouring-nodiag",
                           uppertox.constraint=NULL,epsilon=1,mode="sim")
      dose = pickone(design)
      mtd = which(true1==0.3,arr.ind=T)
      same = matrix(NA,nrow=2000,ncol=dim(mtd)[1])
      for(q in 1:2000){
        for(z in 1:dim(mtd)[1]){
          same[q,z] = 1*(mtd[z,1]==dose[q,1] & mtd[z,2]==dose[q,2])
        }
      }
      success=apply(same,1,sum)
      sc1[x1,x2,x3] = 100*mean(success)
    }
  }
}
round(sc1,1)

sc2=array(NA,dim=c(length(low),length(inc),length(ss)))
for(x1 in 1:length(low)){
  for(x2 in 1:length(inc)){
    for(x3 in 1:length(ss)){
      design = pipe.design(N=36,S=2000,c=3,theta=0.3,pi=true2, 
                           prior.med=prior.m(low[x1],inc[x2]), prior.ss=matrix(nrow=3,ncol=3,ss[x3]),
                           strategy="ss-random",admis="closest",constraint="neighbouring-nodiag",
                           uppertox.constraint=NULL,epsilon=1,mode="sim")
      dose = pickone(design)
      mtd = which(true2==0.3,arr.ind=T)
      same = matrix(NA,nrow=2000,ncol=dim(mtd)[1])
      for(q in 1:2000){
        for(z in 1:dim(mtd)[1]){
          same[q,z] = (mtd[z,1]==dose[q,1] & mtd[z,2]==dose[q,2])
        }
      }
      success=apply(same,1,sum)
      sc2[x1,x2,x3] = 100*mean(success)
    }
  }
}
round(sc2,1)

sc3=array(NA,dim=c(length(low),length(inc),length(ss)))
for(x1 in 1:length(low)){
  for(x2 in 1:length(inc)){
    for(x3 in 1:length(ss)){
      design = pipe.design(N=36,S=2000,c=3,theta=0.3,pi=true3, 
                           prior.med=prior.m(low[x1],inc[x2]), prior.ss=matrix(nrow=3,ncol=3,ss[x3]),
                           strategy="ss-random",admis="closest",constraint="neighbouring-nodiag",
                           uppertox.constraint=NULL,epsilon=1,mode="sim")
      dose = pickone(design)
      mtd = which(true3==0.3,arr.ind=T)
      same = matrix(NA,nrow=2000,ncol=dim(mtd)[1])
      for(q in 1:2000){
        for(z in 1:dim(mtd)[1]){
          same[q,z] = (mtd[z,1]==dose[q,1] & mtd[z,2]==dose[q,2])
        }
      }
      success=apply(same,1,sum)
      sc3[x1,x2,x3] = 100*mean(success)
    }
  }
}
round(sc3,1)

sc4=array(NA,dim=c(length(low),length(inc),length(ss)))
for(x1 in 1:length(low)){
  for(x2 in 1:length(inc)){
    for(x3 in 1:length(ss)){
      design = pipe.design(N=36,S=2000,c=3,theta=0.3,pi=true4, 
                           prior.med=prior.m(low[x1],inc[x2]), prior.ss=matrix(nrow=3,ncol=3,ss[x3]),
                           strategy="ss-random",admis="closest",constraint="neighbouring-nodiag",
                           uppertox.constraint=NULL,epsilon=1,mode="sim")
      dose = pickone(design)
      mtd = which(true4==0.3,arr.ind=T)
      same = matrix(NA,nrow=2000,ncol=dim(mtd)[1])
      for(q in 1:2000){
        for(z in 1:dim(mtd)[1]){
          same[q,z] = (mtd[z,1]==dose[q,1] & mtd[z,2]==dose[q,2])
        }
      }
      success=apply(same,1,sum)
      sc4[x1,x2,x3] = 100*mean(success)
    }
  }
}
round(sc4,1)

sc1
sc2
sc3
sc4

########################################################################

## Average PCS across scenarios 

#geometric mean
gm=mm=array(NA,dim=c(length(low),length(inc),length(ss)))
for(i in 1:length(low)){
  for(j in 1:length(inc)){
    for(k in 1:length(ss)){
      gm[i,j,k]=(sc1[i,j,k]*sc2[i,j,k]*sc3[i,j,k]*sc4[i,j,k])^(0.25)
      mm[i,j,k]=min(c(sc1[i,j,k],sc2[i,j,k],sc3[i,j,k],sc4[i,j,k]))
    }
  }
}
round(gm,1)
round(mm,1)
min(gm)
which(gm==max(gm),arr.ind=T)
which(gm>38,arr.ind=T)
which(mm==max(mm),arr.ind=T)

library(ggplot2)
x <- c("0.025","0.05","0.075","0.10")
y <- c("0.025","0.05","0.075","0.10")
data <- expand.grid(X=x, Y=y)
data$GM1 <- as.vector(gm[,,1])
data$GM2 <- as.vector(gm[,,2])
data$GM3 <- as.vector(gm[,,3])
data$GM4 <- as.vector(gm[,,4])

pdf(file="fig_PIPE_prior1.pdf",width=4,height=3)
ggplot(data,aes(x=data$X,y=data$Y,fill=(data$GM1))) + geom_tile() + scale_fill_gradient(low="white", high="darkblue",limits=c(30,40)) +
  labs(x=expression(rho),y=expression(delta),fill="Mean \nPCS (%)") + theme(legend.key.height=unit(1, "cm")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

pdf(file="fig_PIPE_prior2.pdf",width=4,height=3)
ggplot(data,aes(x=data$X,y=data$Y,fill=(data$GM2))) + geom_tile() + scale_fill_gradient(low="white", high="darkblue",limits=c(30,40)) +
  labs(x=expression(rho),y=expression(delta),fill="Mean \nPCS (%)") + theme(legend.key.height=unit(1, "cm")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

pdf(file="fig_PIPE_prior3.pdf",width=4,height=3)
ggplot(data,aes(x=data$X,y=data$Y,fill=(data$GM3))) + geom_tile() + scale_fill_gradient(low="white", high="darkblue",limits=c(30,40)) +
  labs(x=expression(rho),y=expression(delta),fill="Mean \nPCS (%)") + theme(legend.key.height=unit(1, "cm")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

pdf(file="fig_PIPE_prior4.pdf",width=4,height=3)
ggplot(data,aes(x=data$X,y=data$Y,fill=(data$GM4))) + geom_tile() + scale_fill_gradient(low="white", high="darkblue",limits=c(30,40)) +
  labs(x=expression(rho),y=expression(delta),fill="Mean \nPCS (%)") + theme(legend.key.height=unit(1, "cm")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

#########################################################################

## calibrating the overdosing rule
set.seed(800)

#take best values
low=0.05
inc=0.025
ss=1/18
epsilon=seq(from=1,to=0.4,by=-0.02)

trueTOX=matrix(nrow=3,ncol=3,c(0.45,0.5,0.55,0.5,0.55,0.6,0.55,0.6,0.65))
trueSAFE=matrix(nrow=3,ncol=3,c(0.3,0.45,0.5,0.45,0.5,0.55,0.5,0.55,0.6))

tox_sc1=vector()
for(y1 in 1:length(epsilon)){
  simulation = pipe.design(N=36,S=2000,c=3,theta=0.3,pi=trueTOX, 
                           prior.med=prior.m(low,inc), prior.ss=matrix(nrow=3,ncol=3,ss),
                           strategy="ss-random",admis="closest",constraint="neighbouring-nodiag",
                           uppertox.constraint=NULL,epsilon=epsilon[y1],mode="sim")
  pstop = sum(simulation$n.rpII==0)/2000
  tox_sc1[y1] = 100*pstop
}
tox_sc1

tox_sc2a=vector()
for(y1 in 1:length(epsilon)){
  design = pipe.design(N=36,S=2000,c=3,theta=0.3,pi=trueSAFE, 
                       prior.med=prior.m(low,inc), prior.ss=matrix(nrow=3,ncol=3,ss),
                       strategy="ss-random",admis="closest",constraint="neighbouring-nodiag",
                       uppertox.constraint=NULL,epsilon=epsilon[y1],mode="sim")
  dose = pickone(design)
  mtd = which(trueSAFE==0.3,arr.ind=T)
  same = matrix(NA,nrow=2000,ncol=dim(mtd)[1])
  for(q in 1:2000){
    for(z in 1:dim(mtd)[1]){
      same[q,z] = (mtd[z,1]==dose[q,1] & mtd[z,2]==dose[q,2])
    }
  }
  success=apply(same,1,sum)
  tox_sc2a[y1]=100*mean(success)
}
tox_sc2a

pdf(file="fig_PIPE_safe.pdf",width=4.6,height=3.4)
ggplot() + geom_line(aes(x=epsilon,y=tox_sc1,col="red"),size=0.8) + geom_line(aes(x=epsilon,y=tox_sc2a,col="green"),size=0.8) + ylim(0,100) +
  labs(x=expression(epsilon),y="Correct Outcome (%)",color=NULL) +  scale_color_manual(values=c("green"="green","red"="red"), labels=c("Sc 13","Sc 14")) +
  theme(axis.text=element_text(size=12), axis.title = element_text(size=12), legend.title = element_text(size=12), legend.text = element_text(size=12))
dev.off()

which(tox_sc1>85)

#########################################################################

## Simulation

set.seed(1)
s1=matrix(c(0.05,0.10,0.15,0.10,0.15,0.20,0.15,0.20,0.30),nrow=3,ncol=3)
s2=matrix(c(0.05,0.10,0.20,0.10,0.20,0.30,0.15,0.30,0.45),nrow=3,ncol=3)
s3=matrix(c(0.02,0.10,0.20,0.05,0.15,0.30,0.10,0.20,0.45),nrow=3,ncol=3)
s4=matrix(c(0.05,0.10,0.20,0.10,0.20,0.45,0.15,0.30,0.60),nrow=3,ncol=3)
s5=matrix(c(0.02,0.20,0.45,0.05,0.30,0.55,0.15,0.45,0.65),nrow=3,ncol=3)
s6=matrix(c(0.10,0.15,0.30,0.15,0.30,0.45,0.30,0.45,0.60),nrow=3,ncol=3)
s7=matrix(c(0.10,0.15,0.30,0.20,0.30,0.50,0.45,0.50,0.60),nrow=3,ncol=3)
s8=matrix(c(0.05,0.10,0.30,0.10,0.20,0.45,0.20,0.30,0.55),nrow=3,ncol=3)
s9=matrix(c(0.10,0.30,0.40,0.15,0.40,0.50,0.30,0.50,0.60),nrow=3,ncol=3)
s10=matrix(c(0.15,0.30,0.45,0.30,0.45,0.55,0.45,0.55,0.65),nrow=3,ncol=3)
s11=matrix(c(0.02,0.30,0.45,0.05,0.45,0.60,0.10,0.60,0.75),nrow=3,ncol=3)
s12=matrix(c(0.20,0.45,0.65,0.30,0.50,0.70,0.45,0.55,0.75),nrow=3,ncol=3)
s13=matrix(c(0.30,0.45,0.50,0.45,0.50,0.55,0.50,0.55,0.60),nrow=3,ncol=3)
s14=matrix(c(0.45,0.50,0.55,0.50,0.55,0.60,0.55,0.60,0.65),nrow=3,ncol=3)
s15=matrix(c(0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10),nrow=3,ncol=3)

scenario=list(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15)

PCS=PAS=PCE=PAE=OVER=PEOVER=ZERO=ntox=npat=rep(NA,15)
EXTRA=SEL=EXP=list()
for(x1 in 1:15){
  trial = pipe.design(N=36,S=2000,c=3, theta=0.30, pi=scenario[[x1]], prior.med=prior.m(0.05, 0.025), prior.ss=matrix(nrow=3,ncol=3,1/18),
                      strategy="ss-random", admis="closest", constraint="neighbouring-nodiag", uppertox.constraint=NULL, epsilon=0.58, mode="sim")
  
  mtd=which(scenario[[x1]]==0.30,arr.ind=T)
  mtds=which((scenario[[x1]]>0.16 & scenario[[x1]]<0.33),arr.ind=T)
  over=which(scenario[[x1]]>0.33,arr.ind=T)
  dose = pickone(trial)
  
  #PCS, PAS, PCE
  if(dim(mtd)[1]!=0){
    pce=vector()
    pae=vector()
    
    same = matrix(NA,nrow=2000,ncol=dim(mtd)[1])
    for(q in 1:2000){
      for(z in 1:dim(mtd)[1]){
        same[q,z] = (mtd[z,1]==dose[q,1] & mtd[z,2]==dose[q,2])
      }
    }
    success=apply(same,1,sum)
    PCS[x1] = 100*mean(success)
    
    extra=vector()
    for(z in 1:dim(mtd)[1]){
      extra[z] = 100*mean(same[,z])
    }
    EXTRA[[x1]] = extra
    
    for(z in 1:dim(mtd)[1]){
      pce[z]=100*trial$exp[mtd[z,1],mtd[z,2]]
    }
    PCE[x1]=sum(pce)
    
    same2 = matrix(NA,nrow=2000,ncol=dim(mtds)[1])
    for(q in 1:2000){
      for(z in 1:dim(mtds)[1]){
        same2[q,z] = (mtds[z,1]==dose[q,1] & mtds[z,2]==dose[q,2])
      }
    }
    success2=apply(same2,1,sum)
    PAS[x1] = 100*mean(success2)
    
    for(z in 1:dim(mtds)[1]){
      pae[z]=100*trial$exp[mtds[z,1],mtds[z,2]]
    }
    PAE[x1]=sum(pae)
  }else{
    PCS[x1]=0
    PAS[x1]=0
    PCE[x1]=0
    PAE[x1]=0
  }
  
  #Overtoxic rec
  if(dim(over)[1]!=0){
    same3 = matrix(NA,nrow=2000,ncol=dim(over)[1])
    for(q in 1:2000){
      for(z in 1:dim(over)[1]){
        same3[q,z] = (over[z,1]==dose[q,1] & over[z,2]==dose[q,2])
      }
    }
    success3=apply(same3,1,sum)
    OVER[x1]=100*mean(success3)
    
    peover=vector()
    for(z in 1:dim(over)[1]){
      peover[z]=100*trial$exp[over[z,1],over[z,2]]
    }
    PEOVER[x1]=sum(peover)
    
  }else{
    OVER[x1]=0
    PEOVER[x1]=0
  }
  
  #Number of patients and DLTs
  tox=pat=vector()
  for(z in 1:2000){
    tox[z]=sum(trial$r.sim[[z]])
    pat[z]=sum(trial$n.sim[[z]])
  }
  ntox[x1]=mean(tox)
  npat[x1]=mean(pat)
  
  SELE=matrix(NA,nrow=3,ncol=3)
  for(i in 1:3){
    for(j in 1:3){
      sel=rep(NA,2000)
      for(k in 1:2000){
        sel[k]=100*(dose[k,1]==i & dose[k,2]==j)
      }
      SELE[i,j]=mean(sel)
    }
  }
  SEL[[x1]]=SELE
  
  EXP[[x1]]=trial$exp * npat[x1]
}

p_PCS=p_PCS
p_PAS=PAS
p_OVER=OVER
p_PEOVER=PEOVER
p_PCE=PCE
p_PAE=PAE
p_ntox=ntox
p_npat=npat
p_EXTRA=EXTRA
p_SEL=SEL
p_EXP=EXP